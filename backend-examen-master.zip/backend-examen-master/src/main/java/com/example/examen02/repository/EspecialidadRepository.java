package com.example.examen02.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.examen02.entity.Especialidad;

public interface EspecialidadRepository extends JpaRepository<Especialidad, Long> {

}
