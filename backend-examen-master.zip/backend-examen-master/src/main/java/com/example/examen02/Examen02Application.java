package com.example.examen02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen02Application {

    public static void main(String[] args) {
        SpringApplication.run(Examen02Application.class, args);
    }

}
