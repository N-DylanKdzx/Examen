import { Component, OnInit } from '@angular/core';
import { CardComponent } from '../card/card.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { Especialidad } from '../especialidad/models/especialidad';
import { Doctor } from './models/doctor';
import { DoctorService } from '../doctor/service/doctor.service';
import { EspecialidadService } from '../especialidad/service/especialidad.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-doctor',
  standalone: true,
  imports: [CardComponent, NavbarComponent, CommonModule, FormsModule],
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {
  titulo = 'Gestión de Doctores';
  icono = 'fa-solid fa-stethoscope';
  especialidades: Especialidad[] = [];
  doctores: Doctor[] = [];
  doctorSeleccionado: Doctor = new Doctor(); // Para editar o crear un nuevo doctor
  opc: string = '';
  visible: boolean = false; 
  isDeleteInProgress: boolean = false;
  
  constructor(
    private doctorService: DoctorService,
    private especialidadService: EspecialidadService
  ) {}

  ngOnInit(): void {
    this.listarEspecialidades();
    this.listarDoctores();
  }

  listarEspecialidades(): void {
    this.especialidadService.getEspecialidades().subscribe((data) => {
      this.especialidades = data;
    });
  }

  listarDoctores(): void {
    this.doctorService.getDoctores().subscribe((data) => {
      this.doctores = data;
    });
  }

  mostrarFormulario(opc: string, doctor?: Doctor): void {
    this.opc = opc;
    this.doctorSeleccionado = doctor ? { ...doctor } : new Doctor();
    this.visible = true; // Muestra el formulario
  }

  crearDoctor(): void {
    this.doctorService.crearDoctor(this.doctorSeleccionado).subscribe((nuevoDoctor) => {
      this.doctores.push(nuevoDoctor);
      this.visible = false;
      this.doctorSeleccionado = new Doctor();
      this.listarDoctores(); // Refresca la lista
    });
  }

  editarDoctor(): void {
    if (this.doctorSeleccionado && this.doctorSeleccionado.id) {
      this.doctorService.editarDoctor(this.doctorSeleccionado, this.doctorSeleccionado.id).subscribe(() => {
        this.listarDoctores(); // Refresca la lista
        this.visible = false; // Oculta el formulario
      });
    }
  }

  eliminarDoctor(id: number): void {
    if (confirm('¿Estás seguro de que deseas eliminar este doctor?')) {
      this.isDeleteInProgress = true; // Indica que la eliminación está en progreso
      this.doctorService.eliminarDoctor(id).subscribe(() => {
        this.doctores = this.doctores.filter((doctor) => doctor.id !== id); // Remueve el doctor de la lista
        this.isDeleteInProgress = false;
      });
    }
  }

  guardarDoctor(): void {
    if (this.opc === 'crear') {
      this.crearDoctor();
    } else if (this.opc === 'editar') {
      this.editarDoctor();
    }
  }

  cancelar(): void {
    this.visible = false;
    this.doctorSeleccionado = new Doctor(); // Limpia la selección
  }
}
