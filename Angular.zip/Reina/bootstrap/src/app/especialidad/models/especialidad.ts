export class Especialidad {
    id:number;
    nombre:string;
    constructor(id: number = 0, nombre: string = '') {
      this.id = id;
      this.nombre = nombre;
    } 
}