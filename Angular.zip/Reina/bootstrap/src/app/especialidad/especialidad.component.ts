// src/app/especialidad/especialidad.component.ts
import { Component, OnInit } from '@angular/core';
import { CardComponent } from '../card/card.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { Especialidad } from './models/especialidad';
import { EspecialidadService } from './service/especialidad.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-especialidad',
  standalone: true,
  imports: [CardComponent, NavbarComponent, CommonModule, FormsModule],
  templateUrl: './especialidad.component.html',
  styleUrls: ['./especialidad.component.css']
})
export class EspecialidadComponent implements OnInit {
  titulo = 'Gestión de Especialidades';
  icono = 'fa-solid fa-shapes';
  especialidades: Especialidad[] = [];
  especialidadSeleccionada: Especialidad = new Especialidad();
  isEditMode: boolean = false;

  constructor(private especialidadService: EspecialidadService) {}

  ngOnInit(): void {
    this.listarEspecialidades();
  }

  listarEspecialidades() {
    this.especialidadService.getEspecialidades().subscribe((data: Especialidad[]) => {
      this.especialidades = data;
    });
  }

  guardarEspecialidad() {
    if (this.isEditMode) {
      this.especialidadService.editarEspecialidad(this.especialidadSeleccionada, this.especialidadSeleccionada.id)
        .subscribe(() => {
          this.listarEspecialidades();
          this.resetFormulario();
        });
    } else {
      this.especialidadService.crearEspecialidad(this.especialidadSeleccionada)
        .subscribe(() => {
          this.listarEspecialidades();
          this.resetFormulario();
        });
    }
  }

  editarEspecialidad(especialidad: Especialidad) {
    this.especialidadSeleccionada = { ...especialidad };
    this.isEditMode = true;
  }

  eliminarEspecialidad(id: number) {
    this.especialidadService.eliminarEspecialidad(id).subscribe(() => {
      this.listarEspecialidades();
    });
  }

  resetFormulario() {
    this.especialidadSeleccionada = new Especialidad();
    this.isEditMode = false;
  }
}
