export class Producto {
}
